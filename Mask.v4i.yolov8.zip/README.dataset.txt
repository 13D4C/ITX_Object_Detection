# Mask > 2023-09-11 2:45pm
https://universe.roboflow.com/d4c-onv4b/mask-mpyyz

Provided by a Roboflow user
License: CC BY 4.0

